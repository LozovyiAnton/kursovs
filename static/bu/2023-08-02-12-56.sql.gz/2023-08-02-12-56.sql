CREATE DATABASE IF NOT EXISTS`passport`;
USE `passport`;


CREATE TABLE IF NOT EXISTS `organ` (
  `code` varchar(4) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `organ` (`code`, `name`, `address`) VALUES
	('1001','Міграційна служба','вул. Центральна, 1, Київ'),
	('1002','Паспортний стол','вул. Леніна, 15, Хмельницький'),
	('1003','Паспортна служба','пр. Незалежності, 70, Черкаси'),
	('1029','Паспортна служба Загублених цивілізацій','пр. Невідомий, 19, Інша дімензія'),
	('1234','Управління паспортного обслуговування','вул. Футуристична, 10, Київ'),
	('1357','Міграційна служба Таємничих аномалій','пр. Дивний, 55, Загадковість'),
	('2001','Паспортний стол','вул. Шевченка, 10, Львів'),
	('2002','Міграційна служба','вул. Садова, 9, Львів'),
	('2003','Міграційна служба','вул. Заводська, 22, Харків'),
	('2468','Департамент паспортів майбутнього','вул. Телепортна, 21, Кіберпростір'),
	('3001','Департамент охорони правопорядку','пр. Миру, 5, Одеса'),
	('3002','Департамент міграції','пр. Перемоги, 30, Київ'),
	('3003','Департамент охорони правопорядку','вул. Грушевського, 9, Київ'),
	('3579','Департамент паралельних реальностей','пр. Паралельний, 77, Мультивсесвіт'),
	('4001','Паспортна служба','вул. Перемоги, 25, Харків'),
	('4002','Паспортна служба','вул. Центральна, 50, Одеса'),
	('4003','Паспортний стол','вул. Леніна, 60, Миколаїв'),
	('4265','Міграційний офіс Часових петель','вул. Часова, 3, Тиметревелія'),
	('4321','Міграційний центр Загадкових сутностей','вул. Небесна, 7, Всесвіт'),
	('4593','Управління паспортами Забутих мрій','вул. Мрійлива, 12, Сновидіння'),
	('5001','Міграційна служба','вул. Привокзальна, 8, Запоріжжя'),
	('5002','Міграційна служба','вул. Головна, 11, Запоріжжя'),
	('5003','Міграційна служба','пр. Перемоги, 18, Запоріжжя'),
	('5678','Департамент міграційних технологій','вул. Кібернетична, 5, Львів'),
	('5731','Департамент забутого минулого','вул. Загадкова, 87, Давність'),
	('6001','Департамент міграції','вул. Соборна, 14, Дніпро'),
	('6002','Департамент охорони правопорядку','пр. Миру, 12, Чернігів'),
	('6003','Департамент міграції','вул. Центральна, 5, Житомир'),
	('6248','Паспортний стол Чудових створінь','вул. Фантастична, 23, Фейріленд'),
	('7001','Паспортна служба','вул. Гагаріна, 2, Вінниця'),
	('7002','Паспортний стол','вул. Стара, 17, Вінниця'),
	('7003','Паспортна служба','вул. Шевченка, 25, Вінниця'),
	('7890','Паспортний стол Екзотичних локацій','вул. Тропічна, 30, Парадиз'),
	('8001','Міграційна служба','вул. Козацька, 7, Закарпаття'),
	('8002','Міграційна служба','вул. Соборна, 5, Львів'),
	('8003','Міграційна служба','вул. Садова, 40, Львів'),
	('8642','Управління паспортами Підземного королівства','вул. Містична, 13, Глибини'),
	('9001','Департамент охорони правопорядку','пр. Свободи, 40, Черкаси'),
	('9002','Департамент міграції','вул. Хмельницька, 32, Рівне'),
	('9003','Департамент охорони правопорядку','вул. Миру, 15, Чернівці'),
	('9012','Міграційна служба Зоряних систем','пр. Зірковий, 8, Галактіка'),
	('9876','Паспортна служба Інтергалактичного району','пр. Космічний, 42, Земля');

-- ------------------------------------------------ 



CREATE TABLE IF NOT EXISTS `ukr_pass` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `surname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pb` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sex` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_of_birth` date NOT NULL,
  `end_date` date NOT NULL,
  `num` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conf` int(11) NOT NULL,
  `img` varchar(2555) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gr` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `organ` varchar(4) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user` (`user`),
  KEY `organ` (`organ`),
  CONSTRAINT `ukr_pass_ibfk_1` FOREIGN KEY (`user`) REFERENCES `user` (`id`),
  CONSTRAINT `ukr_pass_ibfk_2` FOREIGN KEY (`organ`) REFERENCES `organ` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `ukr_pass` (`id`, `user`, `name`, `surname`, `pb`, `sex`, `date_of_birth`, `end_date`, `num`, `conf`, `img`, `gr`, `organ`) VALUES
	(3,1,'Вася/Vasia','Пупкін/Pupkin','Іванович','Чоловік/Male','2005-05-22','2033-07-29','41502946','0','https://krot.info/uploads/posts/2022-03/1646169653_3-krot-info-p-smeshnoi-muzhik-smeshnie-foto-4.jpg','Україна/Ukraine','1234'),
	(4,1,'Вася/Vasia','НеПупкін/NePupkin','Іванович','Чоловік/Male','2005-05-22','2033-07-29','55067247',1,'https://krot.info/uploads/posts/2022-03/1646169653_3-krot-info-p-smeshnoi-muzhik-smeshnie-foto-4.jpg','Україна/Ukraine','1002'),
	(12,2,'Ольга/Olha','Пупкін/Pupkin','Дмитрівна','Жінка/Female','2003-07-21','2033-08-02','59695701',1,'https://povaha.org.ua/wp-content/uploads/2017/08/DSC_3084.jpg','Україна/Ukraine','6003'),
	(14,12,'Антон/Anton','Бекмембек/Bekmembek','Іванович','Чоловік/Male','1999-07-21','2033-08-02','75545474',1,'https://img.freepik.com/free-photo/handsome-confident-smiling-man-with-hands-crossed-on-chest_176420-18743.jpg?w=2000','Україна/Ukraine','8001');

-- ------------------------------------------------ 



CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `surname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `img` varchar(2555) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `user` (`id`, `name`, `surname`, `email`, `password`, `gender`, `img`, `city`, `role`) VALUES
	(1,'Вася','Пупкін','qwe123@gmail.com','200820e3227815ed1756a6b531e7e0d2','Чоловік','https://abrakadabra.fun/uploads/posts/2021-12/1640882881_1-abrakadabra-fun-p-nakachennii-muzhchina-1.jpg','Житомир','0'),
	(2,'Женщіна','Пупкін','ewq123@gmail.com','200820e3227815ed1756a6b531e7e0d2','Жінка','https://img.freepik.com/free-photo/portrait-of-a-young-businesswoman-holding-eyeglasses-in-hand-against-gray-backdrop_23-2148029483.jpg?w=2000','Житомир','0'),
	(3,'Admin','Admin','admin@gmail.com','200820e3227815ed1756a6b531e7e0d2','Чоловік','https://p4.wallpaperbetter.com/wallpaper/537/541/239/sunset-background-dandelion-fluff-hd-wallpaper-preview.jpg','admin',1),
	(12,'Антон','Бекмембек','zxc@gmail.com','200820e3227815ed1756a6b531e7e0d2','Чоловік','https://img.freepik.com/premium-photo/beautiful-gay-man-with-glitter-on-face-wearing-crop-top-and-rainbow-lgbt-flag-posing-against-white-background_1258-40632.jpg','Житомир','0');

-- ------------------------------------------------ 



CREATE TABLE IF NOT EXISTS `zak_pass` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `surname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city_of_birth` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sex` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_of_birth` date NOT NULL,
  `end_date` date NOT NULL,
  `num` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conf` int(11) NOT NULL,
  `img` varchar(2555) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gr` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `organ` varchar(4) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user` (`user`),
  KEY `organ` (`organ`),
  CONSTRAINT `zak_pass_ibfk_1` FOREIGN KEY (`user`) REFERENCES `user` (`id`),
  CONSTRAINT `zak_pass_ibfk_2` FOREIGN KEY (`organ`) REFERENCES `organ` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `zak_pass` (`id`, `user`, `name`, `surname`, `city_of_birth`, `sex`, `date_of_birth`, `end_date`, `num`, `conf`, `img`, `gr`, `organ`) VALUES
	(9,2,'Ольга/Olha','Бекмембек/Bekmembek','Житомир/Zhytomyr','Жінка/Female','2005-05-22','2033-08-02','65523623',1,'https://cdn.goodhouse.com.ua/images-jpg/18685/186850.jpg','Україна/Ukraine','4003'),
	(11,1,'Вася/Vasia','Пупкін/Pupkin','Житомир/Zhytomyr','Чоловік/Male','2002-07-21','2033-08-02','02967837',1,'https://www.momjunction.com/wp-content/uploads/2021/02/What-Is-A-Sigma-Male-And-Their-Common-Personality-Trait-910x1024.jpg','Україна/Ukraine','9002');

-- ------------------------------------------------ 

CREATE DATABASE IF NOT EXISTS`passport`;
USE `passport`;


CREATE TABLE IF NOT EXISTS `organ` (
  `code` varchar(4) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `organ` (`code`, `name`, `address`) VALUES
	('1001','Міграційна служба','вул. Центральна, 1, Київ'),
	('1002','Паспортний стол','вул. Леніна, 15, Хмельницький'),
	('1003','Паспортна служба','пр. Незалежності, 70, Черкаси'),
	('1029','Паспортна служба Загублених цивілізацій','пр. Невідомий, 19, Інша дімензія'),
	('1234','Управління паспортного обслуговування','вул. Футуристична, 10, Київ'),
	('1357','Міграційна служба Таємничих аномалій','пр. Дивний, 55, Загадковість'),
	('2001','Паспортний стол','вул. Шевченка, 10, Львів'),
	('2002','Міграційна служба','вул. Садова, 9, Львів'),
	('2003','Міграційна служба','вул. Заводська, 22, Харків'),
	('2468','Департамент паспортів майбутнього','вул. Телепортна, 21, Кіберпростір'),
	('3001','Департамент охорони правопорядку','пр. Миру, 5, Одеса'),
	('3002','Департамент міграції','пр. Перемоги, 30, Київ'),
	('3003','Департамент охорони правопорядку','вул. Грушевського, 9, Київ'),
	('3579','Департамент паралельних реальностей','пр. Паралельний, 77, Мультивсесвіт'),
	('4001','Паспортна служба','вул. Перемоги, 25, Харків'),
	('4002','Паспортна служба','вул. Центральна, 50, Одеса'),
	('4003','Паспортний стол','вул. Леніна, 60, Миколаїв'),
	('4265','Міграційний офіс Часових петель','вул. Часова, 3, Тиметревелія'),
	('4321','Міграційний центр Загадкових сутностей','вул. Небесна, 7, Всесвіт'),
	('4593','Управління паспортами Забутих мрій','вул. Мрійлива, 12, Сновидіння'),
	('5001','Міграційна служба','вул. Привокзальна, 8, Запоріжжя'),
	('5002','Міграційна служба','вул. Головна, 11, Запоріжжя'),
	('5003','Міграційна служба','пр. Перемоги, 18, Запоріжжя'),
	('5678','Департамент міграційних технологій','вул. Кібернетична, 5, Львів'),
	('5731','Департамент забутого минулого','вул. Загадкова, 87, Давність'),
	('6001','Департамент міграції','вул. Соборна, 14, Дніпро'),
	('6002','Департамент охорони правопорядку','пр. Миру, 12, Чернігів'),
	('6003','Департамент міграції','вул. Центральна, 5, Житомир'),
	('6248','Паспортний стол Чудових створінь','вул. Фантастична, 23, Фейріленд'),
	('7001','Паспортна служба','вул. Гагаріна, 2, Вінниця'),
	('7002','Паспортний стол','вул. Стара, 17, Вінниця'),
	('7003','Паспортна служба','вул. Шевченка, 25, Вінниця'),
	('7890','Паспортний стол Екзотичних локацій','вул. Тропічна, 30, Парадиз'),
	('8001','Міграційна служба','вул. Козацька, 7, Закарпаття'),
	('8002','Міграційна служба','вул. Соборна, 5, Львів'),
	('8003','Міграційна служба','вул. Садова, 40, Львів'),
	('8642','Управління паспортами Підземного королівства','вул. Містична, 13, Глибини'),
	('9001','Департамент охорони правопорядку','пр. Свободи, 40, Черкаси'),
	('9002','Департамент міграції','вул. Хмельницька, 32, Рівне'),
	('9003','Департамент охорони правопорядку','вул. Миру, 15, Чернівці'),
	('9012','Міграційна служба Зоряних систем','пр. Зірковий, 8, Галактіка'),
	('9876','Паспортна служба Інтергалактичного району','пр. Космічний, 42, Земля');

-- ------------------------------------------------ 



CREATE TABLE IF NOT EXISTS `ukr_pass` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `surname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pb` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sex` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_of_birth` date NOT NULL,
  `end_date` date NOT NULL,
  `num` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conf` int(11) NOT NULL,
  `img` varchar(2555) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gr` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `organ` varchar(4) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user` (`user`),
  KEY `organ` (`organ`),
  CONSTRAINT `ukr_pass_ibfk_1` FOREIGN KEY (`user`) REFERENCES `user` (`id`),
  CONSTRAINT `ukr_pass_ibfk_2` FOREIGN KEY (`organ`) REFERENCES `organ` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `ukr_pass` (`id`, `user`, `name`, `surname`, `pb`, `sex`, `date_of_birth`, `end_date`, `num`, `conf`, `img`, `gr`, `organ`) VALUES
	(3,1,'Вася/Vasia','Пупкін/Pupkin','Іванович','Чоловік/Male','2005-05-22','2033-07-29','41502946','0','https://krot.info/uploads/posts/2022-03/1646169653_3-krot-info-p-smeshnoi-muzhik-smeshnie-foto-4.jpg','Україна/Ukraine','1234'),
	(4,1,'Вася/Vasia','НеПупкін/NePupkin','Іванович','Чоловік/Male','2005-05-22','2033-07-29','55067247',1,'https://krot.info/uploads/posts/2022-03/1646169653_3-krot-info-p-smeshnoi-muzhik-smeshnie-foto-4.jpg','Україна/Ukraine','1002'),
	(12,2,'Ольга/Olha','Пупкін/Pupkin','Дмитрівна','Жінка/Female','2003-07-21','2033-08-02','59695701',1,'https://povaha.org.ua/wp-content/uploads/2017/08/DSC_3084.jpg','Україна/Ukraine','6003'),
	(14,12,'Антон/Anton','Бекмембек/Bekmembek','Іванович','Чоловік/Male','1999-07-21','2033-08-02','75545474',1,'https://img.freepik.com/free-photo/handsome-confident-smiling-man-with-hands-crossed-on-chest_176420-18743.jpg?w=2000','Україна/Ukraine','8001');

-- ------------------------------------------------ 



CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `surname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `img` varchar(2555) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `user` (`id`, `name`, `surname`, `email`, `password`, `gender`, `img`, `city`, `role`) VALUES
	(1,'Вася','Пупкін','qwe123@gmail.com','200820e3227815ed1756a6b531e7e0d2','Чоловік','https://abrakadabra.fun/uploads/posts/2021-12/1640882881_1-abrakadabra-fun-p-nakachennii-muzhchina-1.jpg','Житомир','0'),
	(2,'Женщіна','Пупкін','ewq123@gmail.com','200820e3227815ed1756a6b531e7e0d2','Жінка','https://img.freepik.com/free-photo/portrait-of-a-young-businesswoman-holding-eyeglasses-in-hand-against-gray-backdrop_23-2148029483.jpg?w=2000','Житомир','0'),
	(3,'Admin','Admin','admin@gmail.com','200820e3227815ed1756a6b531e7e0d2','Чоловік','https://p4.wallpaperbetter.com/wallpaper/537/541/239/sunset-background-dandelion-fluff-hd-wallpaper-preview.jpg','admin',1),
	(12,'Антон','Бекмембек','zxc@gmail.com','200820e3227815ed1756a6b531e7e0d2','Чоловік','https://img.freepik.com/premium-photo/beautiful-gay-man-with-glitter-on-face-wearing-crop-top-and-rainbow-lgbt-flag-posing-against-white-background_1258-40632.jpg','Житомир','0');

-- ------------------------------------------------ 



CREATE TABLE IF NOT EXISTS `zak_pass` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `surname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city_of_birth` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sex` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_of_birth` date NOT NULL,
  `end_date` date NOT NULL,
  `num` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conf` int(11) NOT NULL,
  `img` varchar(2555) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gr` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `organ` varchar(4) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user` (`user`),
  KEY `organ` (`organ`),
  CONSTRAINT `zak_pass_ibfk_1` FOREIGN KEY (`user`) REFERENCES `user` (`id`),
  CONSTRAINT `zak_pass_ibfk_2` FOREIGN KEY (`organ`) REFERENCES `organ` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `zak_pass` (`id`, `user`, `name`, `surname`, `city_of_birth`, `sex`, `date_of_birth`, `end_date`, `num`, `conf`, `img`, `gr`, `organ`) VALUES
	(9,2,'Ольга/Olha','Бекмембек/Bekmembek','Житомир/Zhytomyr','Жінка/Female','2005-05-22','2033-08-02','65523623',1,'https://cdn.goodhouse.com.ua/images-jpg/18685/186850.jpg','Україна/Ukraine','4003'),
	(11,1,'Вася/Vasia','Пупкін/Pupkin','Житомир/Zhytomyr','Чоловік/Male','2002-07-21','2033-08-02','02967837',1,'https://www.momjunction.com/wp-content/uploads/2021/02/What-Is-A-Sigma-Male-And-Their-Common-Personality-Trait-910x1024.jpg','Україна/Ukraine','9002');

-- ------------------------------------------------ 

CREATE DATABASE IF NOT EXISTS`passport`;
USE `passport`;


CREATE TABLE IF NOT EXISTS `organ` (
  `code` varchar(4) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `organ` (`code`, `name`, `address`) VALUES
	('1001','Міграційна служба','вул. Центральна, 1, Київ'),
	('1002','Паспортний стол','вул. Леніна, 15, Хмельницький'),
	('1003','Паспортна служба','пр. Незалежності, 70, Черкаси'),
	('1029','Паспортна служба Загублених цивілізацій','пр. Невідомий, 19, Інша дімензія'),
	('1234','Управління паспортного обслуговування','вул. Футуристична, 10, Київ'),
	('1357','Міграційна служба Таємничих аномалій','пр. Дивний, 55, Загадковість'),
	('2001','Паспортний стол','вул. Шевченка, 10, Львів'),
	('2002','Міграційна служба','вул. Садова, 9, Львів'),
	('2003','Міграційна служба','вул. Заводська, 22, Харків'),
	('2468','Департамент паспортів майбутнього','вул. Телепортна, 21, Кіберпростір'),
	('3001','Департамент охорони правопорядку','пр. Миру, 5, Одеса'),
	('3002','Департамент міграції','пр. Перемоги, 30, Київ'),
	('3003','Департамент охорони правопорядку','вул. Грушевського, 9, Київ'),
	('3579','Департамент паралельних реальностей','пр. Паралельний, 77, Мультивсесвіт'),
	('4001','Паспортна служба','вул. Перемоги, 25, Харків'),
	('4002','Паспортна служба','вул. Центральна, 50, Одеса'),
	('4003','Паспортний стол','вул. Леніна, 60, Миколаїв'),
	('4265','Міграційний офіс Часових петель','вул. Часова, 3, Тиметревелія'),
	('4321','Міграційний центр Загадкових сутностей','вул. Небесна, 7, Всесвіт'),
	('4593','Управління паспортами Забутих мрій','вул. Мрійлива, 12, Сновидіння'),
	('5001','Міграційна служба','вул. Привокзальна, 8, Запоріжжя'),
	('5002','Міграційна служба','вул. Головна, 11, Запоріжжя'),
	('5003','Міграційна служба','пр. Перемоги, 18, Запоріжжя'),
	('5678','Департамент міграційних технологій','вул. Кібернетична, 5, Львів'),
	('5731','Департамент забутого минулого','вул. Загадкова, 87, Давність'),
	('6001','Департамент міграції','вул. Соборна, 14, Дніпро'),
	('6002','Департамент охорони правопорядку','пр. Миру, 12, Чернігів'),
	('6003','Департамент міграції','вул. Центральна, 5, Житомир'),
	('6248','Паспортний стол Чудових створінь','вул. Фантастична, 23, Фейріленд'),
	('7001','Паспортна служба','вул. Гагаріна, 2, Вінниця'),
	('7002','Паспортний стол','вул. Стара, 17, Вінниця'),
	('7003','Паспортна служба','вул. Шевченка, 25, Вінниця'),
	('7890','Паспортний стол Екзотичних локацій','вул. Тропічна, 30, Парадиз'),
	('8001','Міграційна служба','вул. Козацька, 7, Закарпаття'),
	('8002','Міграційна служба','вул. Соборна, 5, Львів'),
	('8003','Міграційна служба','вул. Садова, 40, Львів'),
	('8642','Управління паспортами Підземного королівства','вул. Містична, 13, Глибини'),
	('9001','Департамент охорони правопорядку','пр. Свободи, 40, Черкаси'),
	('9002','Департамент міграції','вул. Хмельницька, 32, Рівне'),
	('9003','Департамент охорони правопорядку','вул. Миру, 15, Чернівці'),
	('9012','Міграційна служба Зоряних систем','пр. Зірковий, 8, Галактіка'),
	('9876','Паспортна служба Інтергалактичного району','пр. Космічний, 42, Земля');

-- ------------------------------------------------ 



CREATE TABLE IF NOT EXISTS `ukr_pass` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `surname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pb` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sex` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_of_birth` date NOT NULL,
  `end_date` date NOT NULL,
  `num` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conf` int(11) NOT NULL,
  `img` varchar(2555) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gr` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `organ` varchar(4) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user` (`user`),
  KEY `organ` (`organ`),
  CONSTRAINT `ukr_pass_ibfk_1` FOREIGN KEY (`user`) REFERENCES `user` (`id`),
  CONSTRAINT `ukr_pass_ibfk_2` FOREIGN KEY (`organ`) REFERENCES `organ` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `ukr_pass` (`id`, `user`, `name`, `surname`, `pb`, `sex`, `date_of_birth`, `end_date`, `num`, `conf`, `img`, `gr`, `organ`) VALUES
	(3,1,'Вася/Vasia','Пупкін/Pupkin','Іванович','Чоловік/Male','2005-05-22','2033-07-29','41502946','0','https://krot.info/uploads/posts/2022-03/1646169653_3-krot-info-p-smeshnoi-muzhik-smeshnie-foto-4.jpg','Україна/Ukraine','1234'),
	(4,1,'Вася/Vasia','НеПупкін/NePupkin','Іванович','Чоловік/Male','2005-05-22','2033-07-29','55067247',1,'https://krot.info/uploads/posts/2022-03/1646169653_3-krot-info-p-smeshnoi-muzhik-smeshnie-foto-4.jpg','Україна/Ukraine','1002'),
	(12,2,'Ольга/Olha','Пупкін/Pupkin','Дмитрівна','Жінка/Female','2003-07-21','2033-08-02','59695701',1,'https://povaha.org.ua/wp-content/uploads/2017/08/DSC_3084.jpg','Україна/Ukraine','6003'),
	(14,12,'Антон/Anton','Бекмембек/Bekmembek','Іванович','Чоловік/Male','1999-07-21','2033-08-02','75545474',1,'https://img.freepik.com/free-photo/handsome-confident-smiling-man-with-hands-crossed-on-chest_176420-18743.jpg?w=2000','Україна/Ukraine','8001');

-- ------------------------------------------------ 



CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `surname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `img` varchar(2555) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `user` (`id`, `name`, `surname`, `email`, `password`, `gender`, `img`, `city`, `role`) VALUES
	(1,'Вася','Пупкін','qwe123@gmail.com','200820e3227815ed1756a6b531e7e0d2','Чоловік','https://abrakadabra.fun/uploads/posts/2021-12/1640882881_1-abrakadabra-fun-p-nakachennii-muzhchina-1.jpg','Житомир','0'),
	(2,'Женщіна','Пупкін','ewq123@gmail.com','200820e3227815ed1756a6b531e7e0d2','Жінка','https://img.freepik.com/free-photo/portrait-of-a-young-businesswoman-holding-eyeglasses-in-hand-against-gray-backdrop_23-2148029483.jpg?w=2000','Житомир','0'),
	(3,'Admin','Admin','admin@gmail.com','200820e3227815ed1756a6b531e7e0d2','Чоловік','https://p4.wallpaperbetter.com/wallpaper/537/541/239/sunset-background-dandelion-fluff-hd-wallpaper-preview.jpg','admin',1),
	(12,'Антон','Бекмембек','zxc@gmail.com','200820e3227815ed1756a6b531e7e0d2','Чоловік','https://img.freepik.com/premium-photo/beautiful-gay-man-with-glitter-on-face-wearing-crop-top-and-rainbow-lgbt-flag-posing-against-white-background_1258-40632.jpg','Житомир','0');

-- ------------------------------------------------ 



CREATE TABLE IF NOT EXISTS `zak_pass` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `surname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city_of_birth` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sex` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_of_birth` date NOT NULL,
  `end_date` date NOT NULL,
  `num` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conf` int(11) NOT NULL,
  `img` varchar(2555) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gr` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `organ` varchar(4) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user` (`user`),
  KEY `organ` (`organ`),
  CONSTRAINT `zak_pass_ibfk_1` FOREIGN KEY (`user`) REFERENCES `user` (`id`),
  CONSTRAINT `zak_pass_ibfk_2` FOREIGN KEY (`organ`) REFERENCES `organ` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `zak_pass` (`id`, `user`, `name`, `surname`, `city_of_birth`, `sex`, `date_of_birth`, `end_date`, `num`, `conf`, `img`, `gr`, `organ`) VALUES
	(9,2,'Ольга/Olha','Бекмембек/Bekmembek','Житомир/Zhytomyr','Жінка/Female','2005-05-22','2033-08-02','65523623',1,'https://cdn.goodhouse.com.ua/images-jpg/18685/186850.jpg','Україна/Ukraine','4003'),
	(11,1,'Вася/Vasia','Пупкін/Pupkin','Житомир/Zhytomyr','Чоловік/Male','2002-07-21','2033-08-02','02967837',1,'https://www.momjunction.com/wp-content/uploads/2021/02/What-Is-A-Sigma-Male-And-Their-Common-Personality-Trait-910x1024.jpg','Україна/Ukraine','9002');

-- ------------------------------------------------ 

